package ghost;

public class Wall{
    int positionx;
    int positiony;

    public Wall(int positionx,int positiony){
        this.positionx=positionx;
        this.positiony=positiony;
    }
}